﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;

namespace RA8DesenvolupamentTestingQualitat
{
    /// Classe que gestiona la connexió amb la base de dades SQLite i 
    /// les operacions CRUD de les tasques.
    /// (Aquest és el codi "heretat" que els alumnes reben i han d'auditar).
    public class GestorTasques
    {
        // Cadena de connexió a la base de dades local. 
        // L'arxiu 'tasques.db' es crearà automàticament 
        // a la carpeta de l'executable (bin/Debug)
        private string connectionString = "Data Source=tasques.db;Version=3;";

        public GestorTasques()
        {
            // Quan s'instancia la classe, 
            // ens assegurem que la base de dades estigui a punt
            InicialitzarBaseDeDades();
        }

        /// Crea l'arxiu de la base de dades 
        /// i la taula 'Tasques' si no existeixen prèviament.
        private void InicialitzarBaseDeDades()
        {
            using (SQLiteConnection conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string sql = "CREATE TABLE IF NOT EXISTS Tasques (" +
                             "Id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                             "Descripcio TEXT, " +
                             "DataLimit TEXT, " +
                             "Completada INTEGER)";

                using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }

        /// Afegeix una nova tasca a la base de dades.
        /// ATENCIÓ: Aquest mètode conté dos errors intencionats per a la pràctica:
        /// 1. No valida si 'descripcio' està buida o és nul·la (Per a la prova NUnit).
        /// 2. Utilitza concatenació de cadenes per formar l'SQL, 
        ///    permetent Injecció SQL (Per a la prova de Seguretat).
        public void AfegirTasca(string descripcio, string dataLimit)
        {
            if (string.IsNullOrWhiteSpace(descripcio))
            {
                throw new ArgumentException("La descripció de la tasca no pot estar buida.");
            }

            using (SQLiteConnection conn = new SQLiteConnection(connectionString))
            {
                conn.Open();

                // 2. CÓDIGO SEGURO: Usamos @descripcio y @dataLimit como "huecos" seguros
                string sql = "INSERT INTO Tasques (Descripcio, DataLimit, Completada) VALUES (@descripcio, @dataLimit, 0)";

                using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                {
                    // 3. Rellenamos los huecos de forma segura
                    cmd.Parameters.AddWithValue("@descripcio", descripcio);
                    cmd.Parameters.AddWithValue("@dataLimit", dataLimit);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        /// Elimina una tasca de la base de dades a partir del seu ID.
        public void EliminarTasca(int id)
        {
            using (SQLiteConnection conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                // Aquí també hi hauria risc si 'id' fos un text, però en ser 'int' és més segur. 
                // Tot i així, la millor pràctica seria parametritzar-ho també.
                string sql = "DELETE FROM Tasques WHERE Id = " + id;

                using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }

        /// Recupera totes les tasques de la base de dades per mostrar-les a la interfície.
        /// Retorna una llista de cadenes de text formatades.
        public List<string> ObtenirTasques()
        {
            List<string> llista = new List<string>();
            using (SQLiteConnection conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string sql = "SELECT * FROM Tasques";

                using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        // Formatem el text per mostrar l'ID i la descripció a la llista 
                        // (ex: "1 - Comprar pa (Límit: 2024-10-15)")
                        llista.Add($"{reader["Id"]} - {reader["Descripcio"]} (Límit: {reader["DataLimit"]})");
                    }
                }
            }
            return llista;
        }
    
    public void Inserir100kTasques()
        {
            using (SQLiteConnection conn = new SQLiteConnection(connectionString))
            {
                conn.Open();

                // Usamos una transacción para que las 100.000 inserciones tarden segundos en vez de horas
                using (var transaction = conn.BeginTransaction())
                {
                    string sql = "INSERT INTO Tasques (Descripcio, DataLimit, Completada) VALUES (@desc, @data, 0)";
                    using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                    {
                        // Preparamos los parámetros fuera del bucle para mayor eficiencia
                        cmd.Parameters.Add(new SQLiteParameter("@desc"));
                        cmd.Parameters.Add(new SQLiteParameter("@data"));

                        for (int i = 1; i <= 100000; i++)
                        {
                            cmd.Parameters["@desc"].Value = "Tasca de prova " + i;
                            cmd.Parameters["@data"].Value = "2026-12-31";
                            cmd.ExecuteNonQuery();
                        }
                    }
                    transaction.Commit();
                }
            }
        }
    }
}
