using System;
using System.Windows.Forms;

namespace RA8DesenvolupamentTestingQualitat
{
    public partial class Form1 : Form
    {
        private GestorTasques gestor;
        public Form1()
        {
            InitializeComponent();
            gestor = new GestorTasques();
            ActualitzarLlista();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnAfegir_Click(object sender, EventArgs e)
        {
            string descripcio = txtDescripcio.Text;
            string data = dtpData.Value.ToString("yyyy-MM-dd"); // Formato estándar para fechas en BD

            // Llamamos al método "heredado" del profesor
            gestor.AfegirTasca(descripcio, data);

            // Refrescamos la lista visible y vaciamos la caja de texto
            ActualitzarLlista();
            txtDescripcio.Clear();
            txtDescripcio.Focus();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (listBoxTasques.SelectedItem != null)
            {
                // El texto seleccionado tiene este formato: "1 - Comprar pa (Límit: 2024-10-15)"
                string seleccio = listBoxTasques.SelectedItem.ToString();

                // Cortamos la cadena de texto por el guion '-' y nos quedamos con la primera parte (el ID)
                string idString = seleccio.Split('-')[0].Trim();

                // Convertimos ese texto a un número entero
                int idTasca = int.Parse(idString);

                // Llamamos al método del profesor para eliminar de la base de datos
                gestor.EliminarTasca(idTasca);

                // Refrescamos la lista visible
                ActualitzarLlista();
            }
            else
            {
                // Si intenta borrar sin seleccionar nada, le mostramos un aviso
                MessageBox.Show("Selecciona una tasca de la llista per eliminar-la.", "Avís", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }



        private void ActualitzarLlista()
        {
            listBoxTasques.DataSource = null;
            listBoxTasques.DataSource = gestor.ObtenirTasques();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ((Button)sender).Enabled = false;

            // 2. Insertamos las 100.000 tareas de golpe
            gestor.Inserir100kTasques();

            // 3. Forzamos a la interfaz a cargar las 100.000 tareas de golpe en el ListBox
            ActualitzarLlista();

            MessageBox.Show("Test finalitzat!");
        }
    }

}
