using NUnit.Framework; // Tu namespace principal
using System;
using RA8DesenvolupamentTestingQualitat;

namespace GestorTasquesTests
{
    public class Tests
    {
        [Test]
        public void AfegirTasca_DescripcioBuida_LlancaExcepcio()
        {
            GestorTasques gestor = new GestorTasques();

            Assert.Throws<ArgumentException>(() => gestor.AfegirTasca("", "2026-12-31"));
        }
    }
}