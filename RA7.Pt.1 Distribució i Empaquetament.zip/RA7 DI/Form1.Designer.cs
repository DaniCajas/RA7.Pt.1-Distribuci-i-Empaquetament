﻿namespace RA8DesenvolupamentTestingQualitat
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtDescripcio = new TextBox();
            dtpData = new DateTimePicker();
            btnAfegir = new Button();
            btnEliminar = new Button();
            listBoxTasques = new ListBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // txtDescripcio
            // 
            txtDescripcio.Location = new Point(39, 192);
            txtDescripcio.Name = "txtDescripcio";
            txtDescripcio.Size = new Size(200, 23);
            txtDescripcio.TabIndex = 0;
            // 
            // dtpData
            // 
            dtpData.Location = new Point(39, 150);
            dtpData.Name = "dtpData";
            dtpData.Size = new Size(200, 23);
            dtpData.TabIndex = 1;
            // 
            // btnAfegir
            // 
            btnAfegir.Location = new Point(39, 279);
            btnAfegir.Name = "btnAfegir";
            btnAfegir.Size = new Size(100, 55);
            btnAfegir.TabIndex = 2;
            btnAfegir.Text = "Afegir Tasca";
            btnAfegir.UseVisualStyleBackColor = true;
            btnAfegir.Click += btnAfegir_Click;
            // 
            // btnEliminar
            // 
            btnEliminar.Location = new Point(160, 279);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(97, 55);
            btnEliminar.TabIndex = 3;
            btnEliminar.Text = "Eliminar tasca";
            btnEliminar.UseVisualStyleBackColor = true;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // listBoxTasques
            // 
            listBoxTasques.FormattingEnabled = true;
            listBoxTasques.ItemHeight = 15;
            listBoxTasques.Location = new Point(381, 60);
            listBoxTasques.Name = "listBoxTasques";
            listBoxTasques.Size = new Size(407, 274);
            listBoxTasques.TabIndex = 4;
            // 
            // button1
            // 
            button1.Location = new Point(39, 370);
            button1.Name = "button1";
            button1.Size = new Size(76, 39);
            button1.TabIndex = 5;
            button1.Text = "Generar 100K tasques";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(listBoxTasques);
            Controls.Add(btnEliminar);
            Controls.Add(btnAfegir);
            Controls.Add(dtpData);
            Controls.Add(txtDescripcio);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtDescripcio;
        private DateTimePicker dtpData;
        private Button btnAfegir;
        private Button btnEliminar;
        private ListBox listBoxTasques;
        private Button button1;
    }
}
